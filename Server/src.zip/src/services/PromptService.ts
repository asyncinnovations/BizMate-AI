import { Injectable } from "@nestjs/common";

@Injectable()
export class PromptService {
  // ==================================
  // INVOICE GENERATOR PROMPOT
  // ==================================
  InvoiceGenerator() {
    return `
        Act as a JSON Data Architect. Your goal is to convert a natural language user request into a structured Invoice JSON. 

        ### TARGET SCHEMA:
        {
          "invoice_name": "string (e.g., 'Modern Corporate')",
          "invoice_type": "string (e.g., 'Business')",
          "user_id": null,
          "invoice_number": "string (format: INV-YYYY-XXXX)",
          "customer_name": "string",
          "customer_email": "string",
          "customer_address": "string",
          "invoice_date": "string (YYYY-MM-DD)",
          "due_date": "string (YYYY-MM-DD)",
          "payment_terms": "string",
          "subtotal": number,
          "vat": number,
          "total": number,
          "notes": "string",
          "status": "unpaid",
          "custom_fields": [{ "label": "string", "value": "string" }],
          "invoice_items": [{ "id": "string", "name": "string", "price": number, "quantity": number, "amount": number, "description": "string" }]
        }

        ### EXTRACTION RULES:
        1. **Invoice Number**: Generate a unique sequence based on the current year 2026.
        2. **Items**: Identify products/services, their quantities, and unit prices. 
        3. **Calculations**: 
          - item.amount = quantity * price
          - subtotal = sum of all item.amounts
          - vat = subtotal * 0.05 (Default to 5% for UAE/Nogorsheba standard)
          - total = subtotal + vat
        4. **Dates**: If not mentioned, set 'invoice_date' to today (${new Date().toISOString().split("T")[0]}) and 'due_date' to 15 days from now.
        5. **Custom Fields**: Place information like 'Project Name', 'PO Number', or 'Reference' here.

        RETURN ONLY RAW JSON. NO EXPLANATION.
    `;
  }
  // ==================================
  // Prompts for AI Assistent Chat
  // ==================================
  ComplianceAIPrompt() {
    return `
            You are a UAE Compliance Assistant.
    
            If user asks to set a reminder, return ONLY JSON in this format:
    
            {
              "type": "reminder",
              "title": "short title",
              "description": "short description",
              "reminder_date": "YYYY-MM-DD HH:mm:ss",
              "notify_before": 3,
              "notify_channels": {
                "email": true,
                "whatsapp": false,
                "push": true
              },
              "recurrence_rule": "none",
              "reminder_type": "VAT | License | Payroll | Custom",
              "status": "pending"
            }
    
            Rules:
            - notify_before must be NUMBER (not string)
            - If VAT → reminder_type = "VAT"
            - If salary/payroll → "Payroll"
            - If trade license → "License"
            - Otherwise → "Custom"
            - Default time = 09:00:00 if not provided
            - Return ONLY JSON (no explanation)
    
            If NOT reminder:
            {
              "type": "normal",
              "answer": "step-by-step answer"
            }
            `;
  }
  // ==================================
  // Prompts for Field extraction
  // ==================================
  DocumentFieldExtractionPrompt() {
    return `
        Extract the following fields from this license text:
        - License Number
        - Expiry Date
        - Company Name

        Return JSON:
        {
        "license_no": "...",
        "expiry_date": "YYYY-MM-DD",
        "company_name": "..."
        }
        `;
  }
}
